import tkinter as tk
from tkinter import font as tkfont
import random
import time

# --- CONFIGURACIÓN DE COLORES Y ESTILOS ---
COLORS = {
    "bg_dark": "#0f172a",       # Fondo principal
    "bg_panel": "#1e293b",      # Paneles secundarios
    "primary": "#3b82f6",       # Azul
    "success": "#22c55e",       # Verde
    "error": "#ef4444",         # Rojo
    "text_main": "#f8fafc",     # Texto blanco
    "text_dim": "#94a3b8"       # Texto gris
}

class ClasifiEcoApp(tk.Tk):
    def __init__(self):
        super().__init__()
        
        self.title("Clasifi-Eco | Sistema de Clasificación")
        self.geometry("1024x768")
        self.configure(bg=COLORS["bg_dark"])
        
        # Configuración de fuentes
        self.title_font = tkfont.Font(family="Segoe UI", size=18, weight="bold")
        self.body_font = tkfont.Font(family="Segoe UI", size=12)
        self.metric_font = tkfont.Font(family="Segoe UI", size=14, weight="bold")
        
        # Estado del sistema
        self.is_connected = False
        
        # --- LAYOUT PRINCIPAL ---
        # Sidebar (Izquierda)
        self.sidebar = tk.Frame(self, bg=COLORS["bg_panel"], width=200, highlightthickness=0)
        self.sidebar.pack(side="left", fill="y")
        
        # Título Sidebar
        lbl_title = tk.Label(self.sidebar, text="Clasifi-Eco", 
                             bg=COLORS["bg_panel"], fg=COLORS["primary"], 
                             font=self.title_font, pady=20)
        lbl_title.pack()
        
        # Botones de Navegación
        self.btn_dash = tk.Button(self.sidebar, text="Dashboard", command=lambda: self.show_frame(DashboardView),
                                  bg=COLORS["bg_panel"], fg=COLORS["text_main"], activebackground=COLORS["primary"],
                                  activeforeground="white", bd=0, pady=15, width=20, anchor="w", padx=20, font=self.body_font)
        self.btn_dash.pack(fill="x")
        
        self.btn_console = tk.Button(self.sidebar, text="Consola", command=lambda: self.show_frame(ConsoleView),
                                     bg=COLORS["bg_panel"], fg=COLORS["text_main"], activebackground=COLORS["primary"],
                                     activeforeground="white", bd=0, pady=15, width=20, anchor="w", padx=20, font=self.body_font)
        self.btn_console.pack(fill="x")
        
        # Área de Contenido (Derecha)
        self.container = tk.Frame(self, bg=COLORS["bg_dark"])
        self.container.pack(side="right", fill="both", expand=True)
        
        # Diccionario de frames
        self.frames = {}
        for F in (DashboardView, ConsoleView):
            frame = F(self.container, self)
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")
            
        self.show_frame(DashboardView)
        
        # Iniciar simulación de datos
        self.update_simulation()

    def show_frame(self, cont):
        """Muestra el frame seleccionado y trae al frente."""
        frame = self.frames[cont]
        frame.tkraise()
        
        # Actualizar estilo de botones
        if cont == DashboardView:
            self.btn_dash.configure(bg=COLORS["primary"])
            self.btn_console.configure(bg=COLORS["bg_panel"])
        else:
            self.btn_dash.configure(bg=COLORS["bg_panel"])
            self.btn_console.configure(bg=COLORS["primary"])

    def update_simulation(self):
        """Simula datos en tiempo real para el Dashboard."""
        if self.is_connected:
            # Actualizar métricas aleatoriamente en el dashboard
            if DashboardView in self.frames:
                self.frames[DashboardView].update_metrics()
        
        # Re-ejecutar cada 2 segundos
        self.after(2000, self.update_simulation)

class DashboardView(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg=COLORS["bg_dark"])
        self.controller = controller
        
        # Header
        header = tk.Frame(self, bg=COLORS["bg_dark"], height=60)
        header.pack(fill="x", padx=20, pady=10)
        
        tk.Label(header, text="Panel de Control", bg=COLORS["bg_dark"], 
                 fg=COLORS["text_main"], font=self.controller.title_font).pack(side="left")
        
        # Indicador de Estado
        self.status_indicator = tk.Label(header, text="●", bg=COLORS["bg_dark"], 
                                         fg=COLORS["error"], font=("Arial", 20))
        self.status_indicator.pack(side="right")
        self.status_label = tk.Label(header, text="Desconectado", bg=COLORS["bg_dark"], 
                                     fg=COLORS["error"], font=self.controller.body_font)
        self.status_label.pack(side="right", padx=10)

        # Grid de Métricas (4 Cards)
        metrics_frame = tk.Frame(self, bg=COLORS["bg_dark"])
        metrics_frame.pack(fill="x", padx=20, pady=10)
        
        self.cards = {}
        card_data = [
            ("Residuos", "0", COLORS["primary"]),
            ("Tiempo Prom.", "0s", COLORS["primary"]),
            ("Errores", "0", COLORS["error"]),
            ("Reciclable", "0%", COLORS["success"])
        ]
        
        for i, (title, value, color) in enumerate(card_data):
            card = tk.Frame(metrics_frame, bg=COLORS["bg_panel"], padx=20, pady=15)
            card.grid(row=0, column=i, sticky="ew", padx=10)
            metrics_frame.columnconfigure(i, weight=1)
            
            tk.Label(card, text=title, bg=COLORS["bg_panel"], fg=COLORS["text_dim"], font=self.controller.body_font).pack(anchor="w")
            lbl_val = tk.Label(card, text=value, bg=COLORS["bg_panel"], fg=color, font=self.controller.metric_font)
            lbl_val.pack(anchor="w")
            self.cards[title] = lbl_val

        # Panel Central (Cámara)
        cam_frame = tk.Frame(self, bg=COLORS["bg_panel"], bd=2, relief="solid")
        cam_frame.pack(fill="both", expand=True, padx=20, pady=10)
        
        tk.Label(cam_frame, text="[ VISTA DE CÁMARA EN VIVO ]", 
                 bg=COLORS["bg_panel"], fg=COLORS["text_dim"], font=("Consolas", 14)).place(relx=0.5, rely=0.5, anchor="center")
        
        self.lbl_detection = tk.Label(cam_frame, text="Esperando objeto...", 
                                      bg=COLORS["bg_panel"], fg=COLORS["primary"], font=("Segoe UI", 16, "bold"))
        self.lbl_detection.place(relx=0.5, rely=0.7, anchor="center")

    def update_metrics(self):
        """Actualiza los valores de las tarjetas aleatoriamente."""
        # Simulación simple de incremento
        current = int(self.cards["Residuos"].cget("text"))
        self.cards["Residuos"].configure(text=str(current + random.randint(0, 2)))
        
        self.cards["Tiempo Prom."].configure(text=f"{random.uniform(1.2, 3.5):.1f}s")
        self.cards["Reciclable"].configure(text=f"{random.randint(85, 99)}%")
        
        # Simular detección
        items = ["Botella PET", "Lata Aluminio", "Cartón", "Plástico HDPE", "Ninguno"]
        item = random.choice(items)
        color = COLORS["success"] if item != "Ninguno" else COLORS["text_dim"]
        self.lbl_detection.configure(text=f"Detectado: {item}", fg=color)

class ConsoleView(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg=COLORS["bg_dark"])
        self.controller = controller
        
        # Header
        header = tk.Frame(self, bg=COLORS["bg_dark"], height=60)
        header.pack(fill="x", padx=20, pady=10)
        tk.Label(header, text="Consola de Control", bg=COLORS["bg_dark"], 
                 fg=COLORS["text_main"], font=self.controller.title_font).pack(side="left")

        # Área de Logs
        log_frame = tk.Frame(self, bg=COLORS["bg_panel"], padx=10, pady=10)
        log_frame.pack(fill="both", expand=True, padx=20, pady=10)
        
        self.log_text = tk.Text(log_frame, bg="#0f172a", fg=COLORS["text_main"], 
                                insertbackground="white", font=("Consolas", 10), bd=0)
        self.log_text.pack(fill="both", expand=True)
        self.log_text.insert("1.0", "> Sistema iniciado...\n")
        self.log_text.config(state="disabled")

        # Panel de Control Inferior
        control_frame = tk.Frame(self, bg=COLORS["bg_dark"])
        control_frame.pack(fill="x", padx=20, pady=20)
        
        # Botones de Movimiento
        move_frame = tk.Frame(control_frame, bg=COLORS["bg_dark"])
        move_frame.pack(side="left")
        
        btn_left = tk.Button(move_frame, text="◀ Mover Izq", command=lambda: self.log_action("Moviendo cinta a IZQUIERDA"),
                             bg=COLORS["bg_panel"], fg=COLORS["text_main"], activebackground=COLORS["primary"], bd=0, padx=15, pady=10)
        btn_left.pack(side="left", padx=5)
        
        btn_right = tk.Button(move_frame, text="Mover Der ▶", command=lambda: self.log_action("Moviendo cinta a DERECHA"),
                              bg=COLORS["bg_panel"], fg=COLORS["text_main"], activebackground=COLORS["primary"], bd=0, padx=15, pady=10)
        btn_right.pack(side="left", padx=5)
        
        # Conexión
        conn_frame = tk.Frame(control_frame, bg=COLORS["bg_dark"])
        conn_frame.pack(side="right")
        
        self.btn_connect = tk.Button(conn_frame, text="CONECTAR", command=self.toggle_connection,
                                     bg=COLORS["success"], fg="white", font=("Segoe UI", 10, "bold"), bd=0, padx=20, pady=10)
        self.btn_connect.pack(side="left", padx=5)
        
        self.btn_disconnect = tk.Button(conn_frame, text="DESCONECTAR", command=self.toggle_connection,
                                        bg=COLORS["error"], fg="white", font=("Segoe UI", 10, "bold"), bd=0, padx=20, pady=10, state="disabled")
        self.btn_disconnect.pack(side="left", padx=5)

    def toggle_connection(self):
        self.controller.is_connected = not self.controller.is_connected
        
        if self.controller.is_connected:
            self.log_action("Conexión establecida con el PLC.")
            self.btn_connect.configure(state="disabled")
            self.btn_disconnect.configure(state="normal")
            # Actualizar indicador en Dashboard
            dash = self.controller.frames[DashboardView]
            dash.status_indicator.configure(fg=COLORS["success"])
            dash.status_label.configure(text="En Línea", fg=COLORS["success"])
        else:
            self.log_action("Conexión interrumpida por el usuario.")
            self.btn_connect.configure(state="normal")
            self.btn_disconnect.configure(state="disabled")
            # Actualizar indicador en Dashboard
            dash = self.controller.frames[DashboardView]
            dash.status_indicator.configure(fg=COLORS["error"])
            dash.status_label.configure(text="Desconectado", fg=COLORS["error"])

    def log_action(self, message):
        self.log_text.config(state="normal")
        timestamp = time.strftime("%H:%M:%S")
        self.log_text.insert("end", f"[{timestamp}] {message}\n")
        self.log_text.see("end") # Auto scroll
        self.log_text.config(state="disabled")

if __name__ == "__main__":
    app = ClasifiEcoApp()
    app.mainloop()