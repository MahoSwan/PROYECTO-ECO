from ultralytics import YOLO

class Detector:
    def __init__(self):
        # Cargar modelo YOLO
        self.model = YOLO("yolov8n.pt")

        # Mapeo a tipos de residuos
        self.mapa = {
            "bottle": "PLASTICO",
            "cup": "PLASTICO",
            "wine glass": "VIDRIO",
            "can": "METAL"
        }

    def detectar(self, frame):
        """Detecta objetos en un frame"""
        resultados = self.model(frame)

        tipos_detectados = []

        for r in resultados:
            for box in r.boxes:
                clase_id = int(box.cls[0])
                nombre = self.model.names[clase_id]

                tipo = self.mapa.get(nombre)

                if tipo:
                    tipos_detectados.append(tipo)

        return resultados, tipos_detectados