import tkinter as tk

# Importar interfaces
from ui.interfaz import Principal
from ui.interfaz_consola import Control


class App(tk.Tk):
    def __init__(self):
        super().__init__()

        # ================== CONFIGURACIÓN VENTANA ==================
        self.title("Clasifi-Eco")
        self.geometry("1000x600")
        self.configure(bg="#eaeaea")

        # ================== DATOS COMPARTIDOS ==================
        # Aquí se guarda TODO lo que usan las pantallas
        self.datos = {
            "residuos": 0,
            "tipo": "N/A",
            "errores": 0,
            "conexion": False
        }

        # ================== BLUETOOTH ==================
        # Se inicializa vacío (luego se conecta en consola)
        self.bt = None

        # ================== CONTENEDOR ==================
        # Frame que contendrá todas las pantallas
        contenedor = tk.Frame(self)
        contenedor.pack(fill="both", expand=True)

        # Permite que las pantallas ocupen todo el espacio
        contenedor.grid_rowconfigure(0, weight=1)
        contenedor.grid_columnconfigure(0, weight=1)

        # ================== PANTALLAS ==================
        self.frames = {}

        # Lista de interfaces
        for F in (Principal, Control):
            frame = F(contenedor, self)

            self.frames[F] = frame

            # Todas se colocan en el mismo lugar
            frame.grid(row=0, column=0, sticky="nsew")

        # Mostrar pantalla inicial
        self.mostrar_frame(Principal)

    # ================== CAMBIO DE PANTALLA ==================
    def mostrar_frame(self, pagina):
        """Cambia entre interfaces"""
        frame = self.frames[pagina]
        frame.tkraise()


# ================== EJECUCIÓN ==================
if __name__ == "__main__":
    app = App()
    app.mainloop()